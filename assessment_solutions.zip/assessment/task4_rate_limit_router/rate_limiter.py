"""Token-aware sliding-window rate limiter, backed by on-disk SQLite.

One row per admitted request: (tenant_key, timestamp, tokens). To admit a
new request we sum tokens for that tenant with timestamp > now - window;
if sum + tokens <= limit it's admitted and a row is inserted in the same
transaction. Rows outside the window get deleted on every check, so the
table stays bounded.

check-then-act is a race under concurrency (two requests could both read
"under limit" and both get admitted), so each tenant gets its own
asyncio.Lock around the read-decide-write sequence. Different tenants
proceed fully in parallel. SQLite runs in WAL mode with BEGIN IMMEDIATE
writes so a second process can't interleave either.
"""
from __future__ import annotations

import asyncio
import sqlite3
import time
from collections import defaultdict
from dataclasses import dataclass

WINDOW_SECONDS = 60.0
DEFAULT_LIMIT_TOKENS_PER_WINDOW = 50_000


@dataclass
class RateLimitResult:
    admitted: bool
    tokens_used_in_window: int
    limit: int
    retry_after_seconds: float | None = None


class SlidingWindowRateLimiter:
    def __init__(
        self,
        db_path: str,
        limit_tokens_per_window: int = DEFAULT_LIMIT_TOKENS_PER_WINDOW,
        window_seconds: float = WINDOW_SECONDS,
    ) -> None:
        self._limit = limit_tokens_per_window
        self._window = window_seconds
        self._locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL;")
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS token_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tenant_key TEXT NOT NULL,
                ts REAL NOT NULL,
                tokens INTEGER NOT NULL
            )
            """
        )
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_tenant_ts ON token_usage(tenant_key, ts)")
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    async def try_consume(self, tenant_key: str, tokens: int) -> RateLimitResult:
        if tokens < 0:
            raise ValueError("tokens must be >= 0")
        async with self._locks[tenant_key]:
            return self._consume_sync(tenant_key, tokens)

    def _consume_sync(self, tenant_key: str, tokens: int) -> RateLimitResult:
        now = time.time()
        window_start = now - self._window

        cur = self._conn.cursor()
        cur.execute("BEGIN IMMEDIATE")
        try:
            cur.execute(
                "DELETE FROM token_usage WHERE tenant_key = ? AND ts <= ?",
                (tenant_key, window_start),
            )
            cur.execute(
                "SELECT COALESCE(SUM(tokens), 0) FROM token_usage WHERE tenant_key = ? AND ts > ?",
                (tenant_key, window_start),
            )
            used = cur.fetchone()[0]

            if used + tokens > self._limit:
                self._conn.commit()
                oldest_ts = self._oldest_ts_in_window(cur, tenant_key, window_start)
                retry_after = max(0.0, (oldest_ts + self._window) - now) if oldest_ts else self._window
                return RateLimitResult(
                    admitted=False,
                    tokens_used_in_window=used,
                    limit=self._limit,
                    retry_after_seconds=round(retry_after, 2),
                )

            cur.execute(
                "INSERT INTO token_usage (tenant_key, ts, tokens) VALUES (?, ?, ?)",
                (tenant_key, now, tokens),
            )
            self._conn.commit()
            return RateLimitResult(admitted=True, tokens_used_in_window=used + tokens, limit=self._limit)
        except Exception:
            self._conn.rollback()
            raise

    @staticmethod
    def _oldest_ts_in_window(cur: sqlite3.Cursor, tenant_key: str, window_start: float) -> float | None:
        cur.execute("SELECT MIN(ts) FROM token_usage WHERE tenant_key = ? AND ts > ?", (tenant_key, window_start))
        row = cur.fetchone()
        return row[0] if row and row[0] is not None else None
