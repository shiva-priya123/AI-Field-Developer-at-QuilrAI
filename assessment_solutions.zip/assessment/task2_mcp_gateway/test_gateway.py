"""
Tests the gateway against the real downstream_server app, both run in-process
via httpx.ASGITransport (no real sockets needed) except for the gateway's own
outbound call, which uses real httpx -- so we spin the downstream app up on a
real local port for that hop, and hit the gateway app in-process.

Run: python3 -I test_gateway.py
"""
import asyncio
import json
import threading
import time

import httpx
import uvicorn

import downstream_server
import gateway

PASS = 0
FAIL = 0


def check(label: str, cond: bool, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS: {label}")
    else:
        FAIL += 1
        print(f"  FAIL: {label} {extra}")


def run_downstream_in_thread(port: int):
    config = uvicorn.Config(downstream_server.app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)

    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    # wait for it to come up
    for _ in range(50):
        try:
            httpx.get(f"http://127.0.0.1:{port}/mcp")
            break
        except httpx.ConnectError:
            time.sleep(0.1)
    return server


async def main():
    port = 9001
    gateway.DOWNSTREAM_URL = f"http://127.0.0.1:{port}/mcp"
    run_downstream_in_thread(port)

    transport = httpx.ASGITransport(app=gateway.app)
    async with httpx.AsyncClient(transport=transport, base_url="http://gateway.local") as client:

        # 1. tools/list forwards transparently, no auth required
        resp = await client.post("/mcp", json={"jsonrpc": "2.0", "id": 1, "method": "tools/list"})
        body = resp.json()
        names = {t["name"] for t in body["result"]["tools"]}
        check("tools/list forwarded with all tools", names == {
            "get_weather", "list_orders", "admin_reset_key", "admin_delete_user"
        }, names)

        # 2. non-admin tool call, no auth header -> allowed
        resp = await client.post(
            "/mcp",
            json={"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                  "params": {"name": "get_weather", "arguments": {"city": "Mumbai"}}},
        )
        body = resp.json()
        check("non-admin tool call without auth succeeds", "result" in body, body)

        # 3. admin tool call, no auth header -> blocked with -32001
        resp = await client.post(
            "/mcp",
            json={"jsonrpc": "2.0", "id": 3, "method": "tools/call",
                  "params": {"name": "admin_reset_key", "arguments": {}}},
        )
        body = resp.json()
        check(
            "admin tool call without auth -> -32001",
            body.get("error", {}).get("code") == -32001,
            body,
        )

        # 4. admin tool call, viewer token -> blocked with -32001
        resp = await client.post(
            "/mcp",
            headers={"Authorization": "Bearer viewer-secret-token"},
            json={"jsonrpc": "2.0", "id": 4, "method": "tools/call",
                  "params": {"name": "admin_delete_user", "arguments": {"user_id": "u1"}}},
        )
        body = resp.json()
        check(
            "admin tool call with viewer token -> -32001",
            body.get("error", {}).get("code") == -32001,
            body,
        )

        # 5. admin tool call, admin token -> forwarded and succeeds
        resp = await client.post(
            "/mcp",
            headers={"Authorization": "Bearer admin-secret-token"},
            json={"jsonrpc": "2.0", "id": 5, "method": "tools/call",
                  "params": {"name": "admin_reset_key", "arguments": {"tenant": "acme"}}},
        )
        body = resp.json()
        check(
            "admin tool call with admin token -> forwarded, result present",
            "result" in body and "admin_reset_key" in body["result"]["content"][0]["text"],
            body,
        )

        # 6. admin tool call, garbage/unknown token -> blocked
        resp = await client.post(
            "/mcp",
            headers={"Authorization": "Bearer not-a-real-token"},
            json={"jsonrpc": "2.0", "id": 6, "method": "tools/call",
                  "params": {"name": "admin_reset_key", "arguments": {}}},
        )
        body = resp.json()
        check(
            "admin tool call with unknown token -> -32001",
            body.get("error", {}).get("code") == -32001,
            body,
        )

        # 7. malformed JSON body -> parse error, not a 500
        resp = await client.post("/mcp", content=b"{not json", headers={"content-type": "application/json"})
        body = resp.json()
        check("malformed JSON -> -32700 parse error", body.get("error", {}).get("code") == -32700, body)

        # 8. id is preserved through blocking path
        resp = await client.post(
            "/mcp",
            json={"jsonrpc": "2.0", "id": "req-xyz", "method": "tools/call",
                  "params": {"name": "admin_reset_key", "arguments": {}}},
        )
        body = resp.json()
        check("request id preserved on blocked call", body.get("id") == "req-xyz", body)

    print(f"\n{PASS} passed, {FAIL} failed")
    import sys
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    asyncio.run(main())
