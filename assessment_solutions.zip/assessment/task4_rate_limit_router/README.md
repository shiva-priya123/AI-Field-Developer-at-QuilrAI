# Rate-Limiting & Model Fallback Router

A token-aware sliding-window rate limiter backed by on-disk SQLite, plus a
router that fails over from a primary to a secondary model provider on a
429 or a 3s timeout, always returning a sanitized, standardized response.

## Files

- `rate_limiter.py` — `SlidingWindowRateLimiter`.
- `providers.py` — `ModelProvider` interface + `MockProvider` (scripted
  ok/429/timeout/error modes, so the fallback tests are deterministic).
- `router.py` — `ModelRouter`: rate-limit check, primary call with timeout,
  fallback, sanitized response.
- `gateway_router.py` — HTTP wiring.

## Run

```bash
pip install -r requirements.txt
uvicorn gateway_router:app --port 8070
curl -s localhost:8070/v1/completions -H 'content-type: application/json' -d \
  '{"tenant_key": "acme-corp", "prompt": "hi", "estimated_tokens": 500}'
```

## Test

```bash
python3 test_rate_limiter.py   # admission, eviction, 20-way concurrency race, on-disk persistence
python3 test_router.py         # success path, 429 failover, timeout failover, error sanitization
python3 test_gateway_e2e.py    # real HTTP round trip
```

## How it works

**Rate limiter.** Each admitted request writes one `(tenant_key,
timestamp, tokens)` row to SQLite. Admission for a new request sums every
row for that tenant with `timestamp > now - 60s` and admits only if
`sum + tokens <= 50000`. The window is anchored to `now` on every call, so
it's a genuine sliding window rather than a fixed/leaky bucket — no double
limit from a burst landing on a bucket boundary. Rows outside the window
get deleted on every call, inside the same transaction, so the table never
grows unbounded.

Checking usage, deciding, and inserting is a check-then-act sequence —
under concurrency, two simultaneous requests could both read "under limit"
and both get admitted. That's closed with one `asyncio.Lock` per tenant
key: a single tenant's read-decide-write is atomic with respect to other
coroutines, while different tenants run fully in parallel.
`test_concurrent_requests_do_not_overshoot_limit` fires 20 simultaneous
1000-token requests at a 10,000-token limit and checks that exactly 10 get
admitted, not "usually around 10."

SQLite runs in WAL mode with `BEGIN IMMEDIATE` writes, so a second writer
process can't interleave mid check-then-act either.

**Router.** The primary call is wrapped in `asyncio.wait_for(timeout=3.0)`.
A 429 or a timeout both trigger failover to the secondary, which gets the
same timeout treatment so a hung secondary can't hang the request either.
`test_primary_timeout_triggers_fallback` checks that failover happens
close to the configured timeout, not after the primary's full (much
longer) simulated latency.

Every response — success or failure — goes through
`GatewaySuccess`/`GatewayError.to_dict()`, so the client only ever sees a
stable `{"error": {"code", "message"}}` shape. Raw provider exception text
(the test fixtures deliberately include a fake file path and a fake
secret) gets logged server-side but never makes it into the response body.
