"""
End-to-end smoke test: spawns server.py as a real subprocess, speaks raw
JSON-RPC over stdin/stdout, and verifies:
  1. Every line on stdout is valid JSON-RPC (nothing stray / non-JSON).
  2. initialize -> tools/list -> tools/call all work.
  3. An invalid tools/call returns a JSON-RPC error with code -32602.
"""
import json
import subprocess
import sys

proc = subprocess.Popen(
    [sys.executable, "-I", "server.py"],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    bufsize=1,
)


def send(msg):
    proc.stdin.write(json.dumps(msg) + "\n")
    proc.stdin.flush()


def recv():
    line = proc.stdout.readline()
    if not line.strip():
        raise RuntimeError("empty line from stdout -- transport broken")
    return json.loads(line)  # will raise if stdout is polluted with non-JSON


try:
    send(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "smoke-test", "version": "0.0.1"},
            },
        }
    )
    init_resp = recv()
    assert "result" in init_resp, init_resp
    print("PASS: initialize ->", init_resp["result"]["serverInfo"])

    send({"jsonrpc": "2.0", "method": "notifications/initialized"})

    send({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
    list_resp = recv()
    names = {t["name"] for t in list_resp["result"]["tools"]}
    assert names == {"get_customer_record", "trigger_refund"}, names
    print("PASS: tools/list ->", names)

    send(
        {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {"name": "get_customer_record", "arguments": {"customer_id": "CUST-00001"}},
        }
    )
    call_resp = recv()
    assert "result" in call_resp, call_resp
    print("PASS: tools/call get_customer_record ->", call_resp["result"]["content"][0]["text"])

    send(
        {
            "jsonrpc": "2.0",
            "id": 4,
            "method": "tools/call",
            "params": {
                "name": "trigger_refund",
                "arguments": {"customer_id": "CUST-00001", "amount": -1, "reason": "bad amount here"},
            },
        }
    )
    err_resp = recv()
    assert "error" in err_resp, err_resp
    assert err_resp["error"]["code"] == -32602, err_resp
    print("PASS: tools/call trigger_refund (invalid amount) -> JSON-RPC error -32602")

    print("\nALL STDIO E2E CHECKS PASSED -- stdout stayed pure JSON-RPC throughout.")
finally:
    proc.terminate()
    try:
        _, stderr_out = proc.communicate(timeout=3)
    except Exception:
        stderr_out = ""
    print("\n--- server stderr (log output, expected non-empty) ---")
    print(stderr_out[-500:] if stderr_out else "(none captured)")
