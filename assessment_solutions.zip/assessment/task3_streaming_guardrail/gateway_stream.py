"""Streaming LLM gateway endpoint with PII redaction applied in real time.

Run:
  uvicorn gateway_stream:app --port 8090

  curl -N -X POST localhost:8090/v1/chat/completions \
    -H 'content-type: application/json' -d '{"prompt": "hi"}'
"""
from __future__ import annotations

import json
import logging
import time
from collections.abc import AsyncIterator

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import StreamingResponse
from starlette.routing import Route

from mock_llm_provider import stream_completion
from redactor import StreamRedactor

logging.basicConfig(level=logging.INFO, format="%(asctime)s [gateway-stream] %(message)s")
logger = logging.getLogger("gateway-stream")


def _sse_event(payload: dict) -> bytes:
    return f"data: {json.dumps(payload)}\n\n".encode("utf-8")


async def _redacted_sse_stream(prompt: str | None) -> AsyncIterator[bytes]:
    redactor = StreamRedactor()
    start = time.monotonic()
    first_byte_sent = False

    async for upstream_chunk in stream_completion(prompt):
        safe_text = redactor.feed(upstream_chunk)
        if safe_text:
            if not first_byte_sent:
                first_byte_sent = True
                logger.info("TTFT: %.1fms", (time.monotonic() - start) * 1000)
            yield _sse_event({"delta": safe_text})

    tail = redactor.flush()
    if tail:
        yield _sse_event({"delta": tail})

    yield _sse_event({"done": True})


async def chat_completions(request: Request) -> StreamingResponse:
    try:
        body = await request.json()
    except Exception:
        body = {}
    prompt = body.get("prompt")

    return StreamingResponse(
        _redacted_sse_stream(prompt),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


app = Starlette(routes=[Route("/v1/chat/completions", chat_completions, methods=["POST"])])
