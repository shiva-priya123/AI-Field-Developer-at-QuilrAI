"""
Unit tests for SlidingWindowRateLimiter: admission logic, eviction, and
concurrency safety (many simultaneous requests for the same tenant must
not collectively exceed the limit).

Run: python3 test_rate_limiter.py
"""
import asyncio
import os
import sys
import tempfile
import time

from rate_limiter import SlidingWindowRateLimiter

PASS = 0
FAIL = 0


def check(label: str, cond: bool, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS: {label}")
    else:
        FAIL += 1
        print(f"  FAIL: {label} {extra}")


async def test_basic_admit_and_block():
    with tempfile.TemporaryDirectory() as d:
        rl = SlidingWindowRateLimiter(os.path.join(d, "t1.db"), limit_tokens_per_window=1000)
        r1 = await rl.try_consume("tenant-a", 600)
        check("first request admitted", r1.admitted, r1)

        r2 = await rl.try_consume("tenant-a", 300)
        check("second request admitted (under limit)", r2.admitted, r2)
        check("usage tracked correctly", r2.tokens_used_in_window == 900, r2)

        r3 = await rl.try_consume("tenant-a", 200)
        check("third request blocked (would exceed limit)", not r3.admitted, r3)
        check("retry_after_seconds populated when blocked", r3.retry_after_seconds is not None, r3)

        rl.close()


async def test_tenants_are_independent():
    with tempfile.TemporaryDirectory() as d:
        rl = SlidingWindowRateLimiter(os.path.join(d, "t2.db"), limit_tokens_per_window=1000)
        a = await rl.try_consume("tenant-a", 1000)
        b = await rl.try_consume("tenant-b", 1000)
        check("tenant-a admitted at its own limit", a.admitted, a)
        check("tenant-b unaffected by tenant-a's usage", b.admitted, b)
        rl.close()


async def test_window_slides_and_evicts():
    with tempfile.TemporaryDirectory() as d:
        rl = SlidingWindowRateLimiter(
            os.path.join(d, "t3.db"), limit_tokens_per_window=100, window_seconds=0.3
        )
        r1 = await rl.try_consume("tenant-x", 90)
        check("first request admitted", r1.admitted, r1)

        r2 = await rl.try_consume("tenant-x", 20)
        check("second request blocked within window", not r2.admitted, r2)

        await asyncio.sleep(0.35)  # let the window slide past the first request

        r3 = await rl.try_consume("tenant-x", 20)
        check("request admitted after window slides (old usage evicted)", r3.admitted, r3)
        check(
            "usage reflects only the new request, old one evicted",
            r3.tokens_used_in_window == 20,
            r3,
        )
        rl.close()


async def test_concurrent_requests_do_not_overshoot_limit():
    """20 concurrent requests of 1000 tokens each against a 10,000 token
    limit -- exactly 10 should be admitted, never more, regardless of
    scheduling order. This is the check-then-act race the per-tenant lock
    exists to close."""
    with tempfile.TemporaryDirectory() as d:
        rl = SlidingWindowRateLimiter(os.path.join(d, "t4.db"), limit_tokens_per_window=10_000)

        async def attempt():
            return await rl.try_consume("tenant-concurrent", 1000)

        results = await asyncio.gather(*[attempt() for _ in range(20)])
        admitted = [r for r in results if r.admitted]
        blocked = [r for r in results if not r.admitted]

        check("exactly 10 of 20 concurrent requests admitted", len(admitted) == 10, len(admitted))
        check("exactly 10 of 20 concurrent requests blocked", len(blocked) == 10, len(blocked))

        total_admitted_tokens = len(admitted) * 1000
        check("admitted tokens never exceed the limit", total_admitted_tokens <= 10_000, total_admitted_tokens)
        rl.close()


async def test_persists_on_disk_across_instances():
    """Proves this is actually on-disk SQLite state, not in-memory."""
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "persist.db")
        rl1 = SlidingWindowRateLimiter(path, limit_tokens_per_window=1000)
        await rl1.try_consume("tenant-p", 700)
        rl1.close()

        rl2 = SlidingWindowRateLimiter(path, limit_tokens_per_window=1000)
        r = await rl2.try_consume("tenant-p", 400)
        check("usage from prior instance persisted on disk", not r.admitted, r)
        rl2.close()


async def main():
    await test_basic_admit_and_block()
    await test_tenants_are_independent()
    await test_window_slides_and_evicts()
    await test_concurrent_requests_do_not_overshoot_limit()
    await test_persists_on_disk_across_instances()

    print(f"\n{PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    asyncio.run(main())
