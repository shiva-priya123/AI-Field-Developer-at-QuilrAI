"""Mock downstream MCP server (HTTP/JSON-RPC) that gateway.py sits in
front of. Run with: uvicorn downstream_server:app --port 9001
"""
from __future__ import annotations

import logging
from typing import Any

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

logging.basicConfig(level=logging.INFO, format="%(asctime)s [downstream] %(message)s")
logger = logging.getLogger("downstream")

TOOLS = [
    {"name": "get_weather", "description": "Get current weather for a city."},
    {"name": "list_orders", "description": "List recent orders for a customer."},
    {"name": "admin_reset_key", "description": "Reset a tenant's API key. Admin only."},
    {"name": "admin_delete_user", "description": "Delete a user account. Admin only."},
]


async def rpc_endpoint(request: Request) -> JSONResponse:
    body: dict[str, Any] = await request.json()
    req_id = body.get("id")
    method = body.get("method")
    params = body.get("params") or {}

    if method == "tools/list":
        return JSONResponse({"jsonrpc": "2.0", "id": req_id, "result": {"tools": TOOLS}})

    if method == "tools/call":
        name = params.get("name")
        arguments = params.get("arguments", {})
        return JSONResponse({
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "content": [{"type": "text", "text": f"executed '{name}' with arguments={arguments}"}],
                "isError": False,
            },
        })

    return JSONResponse({
        "jsonrpc": "2.0", "id": req_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    })


app = Starlette(routes=[Route("/mcp", rpc_endpoint, methods=["POST"])])
