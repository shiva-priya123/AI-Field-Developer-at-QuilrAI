"""MCP gateway proxy: forwards requests to a downstream MCP server, but
blocks tools/call requests for admin_-prefixed tools unless the caller's
bearer token resolves to the admin role.

Run:
  DOWNSTREAM_URL=http://127.0.0.1:9001/mcp uvicorn gateway:app --port 8080
"""
from __future__ import annotations

import logging
import os
from typing import Any

import httpx
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

logging.basicConfig(level=logging.INFO, format="%(asctime)s [gateway] %(message)s")
logger = logging.getLogger("gateway")

DOWNSTREAM_URL = os.environ.get("DOWNSTREAM_URL", "http://127.0.0.1:9001/mcp")

# stand-in for a real token introspection call
TOKEN_ROLES: dict[str, str] = {
    "admin-secret-token": "admin",
    "viewer-secret-token": "viewer",
}

UNAUTHORIZED_TOOL_CALL = -32001
ADMIN_TOOL_PREFIX = "admin_"


def _jsonrpc_error(req_id: Any, code: int, message: str) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}


def _extract_role(request: Request) -> str:
    """Missing/unrecognized tokens resolve to 'viewer' (least privilege),
    never silently to admin."""
    auth_header = request.headers.get("authorization", "")
    if not auth_header.lower().startswith("bearer "):
        return "viewer"

    token = auth_header.split(" ", 1)[1].strip()
    role = TOKEN_ROLES.get(token)
    if role is None:
        logger.warning("unrecognized bearer token presented")
        return "viewer"
    return role


async def _forward_to_downstream(payload: dict[str, Any]) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.post(DOWNSTREAM_URL, json=payload)
        resp.raise_for_status()
        return resp.json()


async def mcp_gateway_endpoint(request: Request) -> JSONResponse:
    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        return JSONResponse(
            _jsonrpc_error(None, -32700, "Parse error: request body is not valid JSON"),
            status_code=400,
        )

    req_id = payload.get("id")
    method = payload.get("method")
    params = payload.get("params") or {}
    role = _extract_role(request)

    if method == "tools/call":
        tool_name = params.get("name", "")
        if tool_name.startswith(ADMIN_TOOL_PREFIX) and role != "admin":
            logger.warning("blocked admin tool call: tool=%s role=%s", tool_name, role)
            return JSONResponse(
                _jsonrpc_error(
                    req_id, UNAUTHORIZED_TOOL_CALL,
                    f"Unauthorized Tool Call: '{tool_name}' requires admin role",
                ),
                status_code=200,  # JSON-RPC errors live in the body, not HTTP status
            )

    # tools/list and everything else just passes through
    result = await _forward_to_downstream(payload)
    return JSONResponse(result)


app = Starlette(routes=[Route("/mcp", mcp_gateway_endpoint, methods=["POST"])])
