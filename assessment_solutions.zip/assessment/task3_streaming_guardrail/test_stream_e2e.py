"""
End-to-end test against the real Starlette app: drives /v1/chat/completions
via httpx.ASGITransport, consumes the SSE stream incrementally (not via
`.json()`/`.text` which would wait for the whole body), and checks:
  1. No raw PII ever appears in any single SSE event or in the joined output.
  2. More than one SSE event is received (i.e. the response is actually
     streamed in pieces, not sent as one giant buffered blob).
  3. A 'done' event arrives at the end.

Run: python3 test_stream_e2e.py
"""
import asyncio
import json
import sys

import httpx

import gateway_stream

PASS = 0
FAIL = 0


def check(label: str, cond: bool, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS: {label}")
    else:
        FAIL += 1
        print(f"  FAIL: {label} {extra}")


async def main():
    transport = httpx.ASGITransport(app=gateway_stream.app)
    async with httpx.AsyncClient(transport=transport, base_url="http://gw.local") as client:
        events = []
        async with client.stream(
            "POST", "/v1/chat/completions", json={"prompt": "give me contact info"}
        ) as resp:
            check("200 OK", resp.status_code == 200, resp.status_code)
            buf = ""
            async for raw in resp.aiter_text():
                buf += raw
                while "\n\n" in buf:
                    event, buf = buf.split("\n\n", 1)
                    if event.startswith("data: "):
                        events.append(json.loads(event[len("data: "):]))

    check("received more than one SSE event (truly streamed)", len(events) > 1, len(events))
    check("last event is the 'done' marker", events[-1] == {"done": True}, events[-1])

    deltas = [e["delta"] for e in events if "delta" in e]
    full_text = "".join(deltas)

    for leaked in ["jane.doe@example.com", "123-45-6789", "4111 1111 1111 1111"]:
        check(f"no leak of {leaked!r} in any single event", all(leaked not in d for d in deltas), deltas)
    check("no leak in joined full text either", all(
        s not in full_text for s in ["jane.doe@example.com", "123-45-6789", "4111 1111 1111 1111"]
    ), full_text)
    check("redaction markers present", full_text.count("[REDACTED]") == 3, full_text)
    check("surrounding plain text preserved", "Let me know if you have other" in full_text, full_text)

    print(f"\n{PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    asyncio.run(main())
