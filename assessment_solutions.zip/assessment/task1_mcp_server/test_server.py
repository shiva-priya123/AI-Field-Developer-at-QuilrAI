"""
Direct unit tests against the tool handlers (no stdio transport needed).

Run: python3 -I test_server.py
"""
import asyncio
import json
import sys

sys.path.insert(0, ".")
from mcp.shared.exceptions import McpError  # noqa: E402
from mcp.types import INVALID_PARAMS, METHOD_NOT_FOUND  # noqa: E402

from server import call_tool, list_tools  # noqa: E402

PASS = 0
FAIL = 0


def check(label: str, cond: bool):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS: {label}")
    else:
        FAIL += 1
        print(f"  FAIL: {label}")


async def main():
    print("list_tools()")
    tools = await list_tools()
    check("returns 2 tools", len(tools) == 2)
    check("names correct", {t.name for t in tools} == {"get_customer_record", "trigger_refund"})

    print("\nget_customer_record - valid, found")
    res = await call_tool("get_customer_record", {"customer_id": "CUST-00001"})
    body = json.loads(res[0].text)
    check("found Asha Rao", body["name"] == "Asha Rao")

    print("\nget_customer_record - valid, not found")
    res = await call_tool("get_customer_record", {"customer_id": "CUST-99999"})
    body = json.loads(res[0].text)
    check("not_found error shape", body["error"] == "not_found")

    print("\nget_customer_record - invalid format (lowercase)")
    try:
        await call_tool("get_customer_record", {"customer_id": "cust-1"})
        check("raises McpError", False)
    except McpError as e:
        check("raises McpError with INVALID_PARAMS", e.error.code == INVALID_PARAMS)

    print("\nget_customer_record - missing field")
    try:
        await call_tool("get_customer_record", {})
        check("raises McpError", False)
    except McpError as e:
        check("raises McpError with INVALID_PARAMS", e.error.code == INVALID_PARAMS)

    print("\ntrigger_refund - valid")
    res = await call_tool(
        "trigger_refund",
        {"customer_id": "CUST-00001", "amount": 25.5, "reason": "Duplicate charge on invoice"},
    )
    body = json.loads(res[0].text)
    check("refund triggered", body["status"] == "refund_triggered")

    print("\ntrigger_refund - negative amount rejected")
    try:
        await call_tool(
            "trigger_refund",
            {"customer_id": "CUST-00001", "amount": -5, "reason": "Duplicate charge"},
        )
        check("raises McpError", False)
    except McpError as e:
        check("raises McpError with INVALID_PARAMS", e.error.code == INVALID_PARAMS)

    print("\ntrigger_refund - zero amount rejected")
    try:
        await call_tool(
            "trigger_refund",
            {"customer_id": "CUST-00001", "amount": 0, "reason": "Duplicate charge"},
        )
        check("raises McpError", False)
    except McpError as e:
        check("raises McpError with INVALID_PARAMS", e.error.code == INVALID_PARAMS)

    print("\ntrigger_refund - reason too short rejected")
    try:
        await call_tool(
            "trigger_refund",
            {"customer_id": "CUST-00001", "amount": 10, "reason": "short"},
        )
        check("raises McpError", False)
    except McpError as e:
        check("raises McpError with INVALID_PARAMS", e.error.code == INVALID_PARAMS)

    print("\ntrigger_refund - bad customer_id format rejected")
    try:
        await call_tool(
            "trigger_refund",
            {"customer_id": "CUST-1", "amount": 10, "reason": "Valid reason text"},
        )
        check("raises McpError", False)
    except McpError as e:
        check("raises McpError with INVALID_PARAMS", e.error.code == INVALID_PARAMS)

    print("\nunknown tool name rejected")
    try:
        await call_tool("delete_everything", {})
        check("raises McpError", False)
    except McpError as e:
        check("raises McpError with METHOD_NOT_FOUND", e.error.code == METHOD_NOT_FOUND)

    print(f"\n{PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    asyncio.run(main())
