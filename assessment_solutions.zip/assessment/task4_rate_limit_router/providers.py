"""Model provider abstraction + a scripted mock used by the test suite to
simulate success/429/timeout/error conditions deterministically. A real
deployment implements ModelProvider.complete() with an actual HTTP client
call to the upstream API.
"""
from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass


class UpstreamRateLimited(Exception):
    pass


class UpstreamError(Exception):
    pass


@dataclass
class CompletionResult:
    provider_name: str
    text: str


class ModelProvider(ABC):
    name: str

    @abstractmethod
    async def complete(self, prompt: str) -> CompletionResult: ...


class MockProvider(ModelProvider):
    """mode: 'ok' | '429' | 'timeout' | 'error'."""

    def __init__(self, name: str, mode: str = "ok", latency: float = 0.01):
        self.name = name
        self.mode = mode
        self.latency = latency

    async def complete(self, prompt: str) -> CompletionResult:
        if self.mode == "timeout":
            await asyncio.sleep(self.latency)
            return CompletionResult(self.name, f"[{self.name}] (late) {prompt}")

        await asyncio.sleep(self.latency)

        if self.mode == "429":
            raise UpstreamRateLimited(f"{self.name} returned 429")
        if self.mode == "error":
            raise UpstreamError(
                f"{self.name} failed: Traceback (most recent call last): "
                f'File "/internal/secret_module.py", line 42, DB password=hunter2'
            )
        return CompletionResult(self.name, f"[{self.name}] {prompt}")
