"""
Unit tests for StreamRedactor: the sliding-window correctness is the whole
point of this task, so these specifically construct chunk splits that land
in the worst possible places (mid-pattern, mid-domain, mid-digit-group).

Run: python3 test_redactor.py
"""
import sys

from redactor import StreamRedactor, REDACTED

PASS = 0
FAIL = 0


def check(label: str, cond: bool, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS: {label}")
    else:
        FAIL += 1
        print(f"  FAIL: {label} {extra}")


def run_stream(chunks: list[str]) -> tuple[str, list[str]]:
    """Feed chunks through a fresh redactor, return (full_output, emitted_pieces)."""
    r = StreamRedactor()
    pieces = []
    for c in chunks:
        out = r.feed(c)
        if out:
            pieces.append(out)
    tail = r.flush()
    if tail:
        pieces.append(tail)
    return "".join(pieces), pieces


def test_email_split_at_at_sign():
    chunks = ["Contact me at jane.doe", "@example.com", " thanks."]
    full, _ = run_stream(chunks)
    check("email split at '@' fully redacted", "jane.doe" not in full and "@example.com" not in full, full)
    check("REDACTED token present", REDACTED in full, full)


def test_email_split_mid_domain():
    chunks = ["Email: jane.doe@exam", "ple", ".com", " for support."]
    full, _ = run_stream(chunks)
    check("email split mid-domain fully redacted", "exam" not in full.replace(REDACTED, ""), full)
    check("no raw '.com' leaked", ".com" not in full, full)


def test_ssn_split_mid_digits():
    chunks = ["SSN on file: 123", "-45", "-6789", " verified."]
    full, _ = run_stream(chunks)
    check("SSN split across 3 chunks fully redacted", "123-45-6789" not in full, full)
    check("REDACTED present for SSN", REDACTED in full, full)


def test_credit_card_split_mid_groups():
    chunks = ["Card: 4111 1111 ", "1111 1111", " on file."]
    full, _ = run_stream(chunks)
    check("credit card split across chunks fully redacted", "4111 1111 1111 1111" not in full, full)
    check("REDACTED present for card", REDACTED in full, full)


def test_one_char_at_a_time():
    """Worst case: every chunk is a single character."""
    text = "Reach out to a.b@c-d.io or card 4111111111111111 or ssn 987-65-4321 done."
    chunks = list(text)
    full, _ = run_stream(chunks)
    check("char-by-char email redacted", "a.b@c-d.io" not in full, full)
    check("char-by-char card redacted", "4111111111111111" not in full, full)
    check("char-by-char ssn redacted", "987-65-4321" not in full, full)
    check("non-PII text preserved", "Reach out to" in full and "done." in full, full)


def test_no_pii_passthrough_unchanged():
    chunks = ["This response ", "has no sensitive ", "data in it at all."]
    full, _ = run_stream(chunks)
    check("plain text passed through unchanged", full == "".join(chunks), full)


def test_incremental_emission_not_buffered_to_end():
    """With a long-enough non-PII preamble, we should get SOME output before
    flush() -- proving we don't hold everything until the stream ends."""
    r = StreamRedactor()
    big_chunk = "x" * 500  # comfortably larger than WINDOW
    out = r.feed(big_chunk)
    check("large chunk yields output before flush()", len(out) > 0, f"len={len(out)}")
    check("some of buffer still held back (window)", len(out) < 500, f"len={len(out)}")


def test_adjacent_pii_not_merged_incorrectly():
    chunks = ["Email a@b.com and SSN 111-22-3333 and card 4111111111111111 end."]
    full, _ = run_stream(chunks)
    check("exactly 3 REDACTED tokens for 3 distinct PII items", full.count(REDACTED) == 3, full)


def main():
    test_email_split_at_at_sign()
    test_email_split_mid_domain()
    test_ssn_split_mid_digits()
    test_credit_card_split_mid_groups()
    test_one_char_at_a_time()
    test_no_pii_passthrough_unchanged()
    test_incremental_emission_not_buffered_to_end()
    test_adjacent_pii_not_merged_incorrectly()

    print(f"\n{PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
