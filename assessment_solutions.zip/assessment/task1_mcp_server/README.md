# MCP Customer-Ops Server

A Python MCP server (stdio transport) with two tools:

- `get_customer_record(customer_id)` — `customer_id` must match `CUST-XXXXX`.
- `trigger_refund(customer_id, amount, reason)` — `amount` must be positive,
  `reason` must be at least 10 characters.

## Run

```bash
pip install -r requirements.txt
python3 server.py
```

## Test

```bash
python3 test_server.py       # handler-level unit tests
python3 test_stdio_e2e.py    # real subprocess, raw JSON-RPC over stdin/stdout
```

## Notes

- All logging goes to stderr (`logging.basicConfig(stream=sys.stderr, ...)`).
  Nothing in `server.py` calls `print()`, so stdout stays pure JSON-RPC —
  `test_stdio_e2e.py` proves it by `json.loads()`-ing every line coming
  back from the subprocess.

- Validation is Pydantic (`GetCustomerRecordInput`, `TriggerRefundInput`).
  Invalid input raises `McpError(INVALID_PARAMS)`, unknown tool names raise
  `McpError(METHOD_NOT_FOUND)`.

- One gotcha: the installed `mcp` SDK's `@server.call_tool()` decorator
  catches *every* exception (including `McpError`) internally and turns it
  into `CallToolResult(isError=True)` — a tool-result-level error, not a
  JSON-RPC protocol error. That's not what the spec wants for bad input
  (invalid args / unknown tool should be real protocol errors, e.g.
  `-32602`). So instead of using the decorator, `server.py` registers the
  `CallToolRequest` handler directly (`server.request_handlers[...]`),
  which lets a raised `McpError` propagate properly and come back as a
  genuine top-level `"error"` field. "record not found" is left as
  ordinary tool content though, since that's a business-logic outcome,
  not a schema problem.
