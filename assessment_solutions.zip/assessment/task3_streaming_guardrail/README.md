# Streaming PII Redaction Guardrail

A streaming LLM gateway endpoint (`gateway_stream.py`) that relays a
completion stream to the client as SSE, redacting emails, SSNs, and credit
card numbers in real time — including patterns split across chunk
boundaries — without buffering the full response.

## Files

- `redactor.py` — `StreamRedactor`, the actual logic. Plain strings in,
  plain strings out, no HTTP involved, so it's trivially unit-testable.
- `mock_llm_provider.py` — a scripted upstream that streams PII split in
  awkward places on purpose (e.g. right after the `@` in an email).
- `gateway_stream.py` — wires provider -> redactor -> client over SSE.

## Run

```bash
pip install -r requirements.txt
uvicorn gateway_stream:app --port 8090
curl -N -X POST localhost:8090/v1/chat/completions \
  -H 'content-type: application/json' -d '{"prompt": "hi"}'
```

## Test

```bash
python3 test_redactor.py     # unit tests, including char-by-char streaming
python3 test_stream_e2e.py   # real HTTP/SSE round trip
```

## How it works

A regex applied to each chunk independently will leak PII whenever a
provider happens to split a token mid-pattern — `"jane.doe"` then
`"@example.com"` as two separate deltas, neither of which matches the
email regex alone.

`StreamRedactor` keeps a small internal buffer. On every `feed(chunk)`:

1. Append the chunk to the buffer.
2. Re-run redaction over the *whole current buffer*, not just the new
   chunk — this is what makes it work regardless of where boundaries fall;
   a pattern gets caught the moment it's fully present, however it arrived.
3. Emit everything except the trailing `WINDOW` characters, held back
   because they might still be an unfinished pattern prefix.
4. `flush()` (called once the stream ends) releases whatever's left.

`WINDOW` is sized to the longest single match any pattern can produce
(email, capped at 153 chars by the regex), plus a little margin. That's
the actual guarantee — a pattern can never get cut by our own flush
boundary, because we never flush closer than `WINDOW` chars from the live
edge of the stream. Buffer size (and therefore memory + latency) stays
`O(WINDOW)`, never `O(response length)`.

No Luhn check on card numbers or range validation on SSNs — this is
format detection, matching what the task asked for.
