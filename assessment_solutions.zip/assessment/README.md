# MCP / LLM Gateway Take-Homes

Four self-contained Python projects, one per task.

| Folder | What it is |
|---|---|
| `task1_mcp_server/` | MCP server with strict input validation over stdio |
| `task2_mcp_gateway/` | MCP proxy gateway with tool-level auth filtering |
| `task3_streaming_guardrail/` | LLM streaming proxy with real-time PII redaction |
| `task4_rate_limit_router/` | Token rate limiter + primary/secondary model fallback |

Each folder has its own `requirements.txt`, server code, test suite, and
README with run instructions and design notes.

## Quick start

```bash
cd task1_mcp_server && pip install -r requirements.txt && python3 test_server.py && python3 test_stdio_e2e.py
cd task2_mcp_gateway && pip install -r requirements.txt && python3 test_gateway.py
cd task3_streaming_guardrail && pip install -r requirements.txt && python3 test_redactor.py && python3 test_stream_e2e.py
cd task4_rate_limit_router && pip install -r requirements.txt && python3 test_rate_limiter.py && python3 test_router.py && python3 test_gateway_e2e.py
```

## Notes

- Task 1 pins `mcp<2` — the SDK's 2.x server API changed significantly and
  most MCP examples/tutorials still target the 1.x decorator style used
  here.
- Tasks 2 and 3's "downstream server" / "upstream LLM provider" are small
  scripted mocks so the gateways can be tested deterministically without
  live API keys. The gateway/proxy code is the actual deliverable; a real
  upstream is a drop-in swap.
- Task 4's `MockProvider` is configurable into success/429/timeout/error
  modes so the fallback and timeout-race tests are fast and deterministic.
