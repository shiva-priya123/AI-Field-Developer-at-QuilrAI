# MCP Security Gateway

A reverse proxy (`gateway.py`, Starlette + httpx) that sits in front of a
downstream MCP server (`downstream_server.py`, a mock) and blocks
`admin_`-prefixed tool calls unless the caller's bearer token resolves to
the admin role.

## Run

```bash
pip install -r requirements.txt

# terminal 1
uvicorn downstream_server:app --port 9001

# terminal 2
DOWNSTREAM_URL=http://127.0.0.1:9001/mcp uvicorn gateway:app --port 8080
```

```bash
# non-admin tool, no auth needed
curl -s localhost:8080/mcp -H 'content-type: application/json' -d \
  '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"get_weather","arguments":{"city":"Mumbai"}}}'

# admin tool without an admin token -> -32001
curl -s localhost:8080/mcp -H 'content-type: application/json' -d \
  '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"admin_reset_key","arguments":{}}}'

# admin tool with admin token -> forwarded
curl -s localhost:8080/mcp -H 'content-type: application/json' \
  -H 'Authorization: Bearer admin-secret-token' -d \
  '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"admin_reset_key","arguments":{}}}'
```

## Test

```bash
python3 test_gateway.py
```

Spins the mock downstream server up on a real port, drives the gateway
in-process through `httpx.ASGITransport`, and checks every auth path:
`tools/list` forwarded transparently, non-admin tools allowed without auth,
admin tools blocked for missing/viewer/unknown tokens, admin tools allowed
with the admin token, malformed JSON handled cleanly, and request `id`
preserved on the blocked path.

## Notes

- `TOKEN_ROLES` is a dict stand-in for a real token-introspection /
  identity-provider call.
- A missing or unrecognized token resolves to `"viewer"` rather than
  erroring outright — non-admin tools still work for an unauthenticated
  caller, but admin tools stay gated either way.
- Only `tools/call` with an `admin_`-prefixed name gets inspected;
  everything else (`tools/list`, `initialize`, etc.) is forwarded as-is.
