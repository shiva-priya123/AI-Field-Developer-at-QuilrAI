"""Incremental PII redaction for a chunked text stream.

The problem: a regex run on each chunk independently will miss a pattern
split across a chunk boundary ("jane.doe" + "@example.com" arriving as two
separate deltas leaks the email, since neither half matches alone).

StreamRedactor keeps a small buffer and re-redacts the whole thing on every
feed() call, then only releases everything except the trailing `window`
characters -- those might still be the unfinished prefix of a pattern
that hasn't fully arrived. `window` just needs to be >= the longest
possible single match (email dominates here, capped by the regex itself).
Memory and "how far behind the model we are" are both O(window), not
O(response length).
"""
from __future__ import annotations

import re

_EMAIL = r"[A-Za-z0-9._%+\-]{1,64}@[A-Za-z0-9.\-]{1,63}\.[A-Za-z]{2,24}"
_SSN = r"\b\d{3}-\d{2}-\d{4}\b"
_CREDIT_CARD = r"\b(?:\d[ -]?){12,18}\d\b"

PII_PATTERNS: dict[str, re.Pattern[str]] = {
    "CREDIT_CARD": re.compile(_CREDIT_CARD),
    "SSN": re.compile(_SSN),
    "EMAIL": re.compile(_EMAIL),
}

# longest possible match above is the email pattern at 153 chars; pad a bit
WINDOW = 153 + 16

REDACTED = "[REDACTED]"


def redact_text(text: str) -> str:
    # order matters: card/SSN before email so a card number isn't partially
    # eaten by the looser email pattern first
    text = PII_PATTERNS["CREDIT_CARD"].sub(REDACTED, text)
    text = PII_PATTERNS["SSN"].sub(REDACTED, text)
    text = PII_PATTERNS["EMAIL"].sub(REDACTED, text)
    return text


class StreamRedactor:
    def __init__(self, window: int = WINDOW) -> None:
        self._window = window
        self._buffer = ""

    def feed(self, chunk: str) -> str:
        self._buffer += chunk
        self._buffer = redact_text(self._buffer)

        if len(self._buffer) <= self._window:
            return ""

        safe_len = len(self._buffer) - self._window
        safe_part = self._buffer[:safe_len]
        self._buffer = self._buffer[safe_len:]
        return safe_part

    def flush(self) -> str:
        remaining = redact_text(self._buffer)
        self._buffer = ""
        return remaining
