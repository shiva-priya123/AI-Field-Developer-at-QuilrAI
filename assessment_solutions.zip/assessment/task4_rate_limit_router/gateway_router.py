"""HTTP wiring for the rate-limiting & fallback router.

POST /v1/completions
  body: {"tenant_key": "...", "prompt": "...", "estimated_tokens": 1234}

Run:
  uvicorn gateway_router:app --port 8070
"""
from __future__ import annotations

import logging
import os

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from providers import MockProvider
from rate_limiter import SlidingWindowRateLimiter
from router import ModelRouter

logging.basicConfig(level=logging.INFO, format="%(asctime)s [gateway-router] %(message)s")

DB_PATH = os.environ.get("RATE_LIMIT_DB", "rate_limit.sqlite3")

rate_limiter = SlidingWindowRateLimiter(DB_PATH)
# swap these two for real HTTP-backed ModelProvider implementations
primary_provider = MockProvider("primary-gpt", mode="ok", latency=0.05)
secondary_provider = MockProvider("secondary-claude", mode="ok", latency=0.05)
router = ModelRouter(rate_limiter, primary_provider, secondary_provider)


async def completions(request: Request) -> JSONResponse:
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": {"code": "BAD_REQUEST", "message": "Request body must be valid JSON"}}, status_code=400)

    tenant_key = body.get("tenant_key")
    prompt = body.get("prompt", "")
    estimated_tokens = body.get("estimated_tokens")

    if not tenant_key or not isinstance(estimated_tokens, int) or estimated_tokens < 0:
        return JSONResponse(
            {"error": {"code": "BAD_REQUEST", "message": "tenant_key (str) and estimated_tokens (non-negative int) are required"}},
            status_code=400,
        )

    payload, status = await router.route(tenant_key, prompt, estimated_tokens)
    return JSONResponse(payload.to_dict(), status_code=status)


app = Starlette(routes=[Route("/v1/completions", completions, methods=["POST"])])
