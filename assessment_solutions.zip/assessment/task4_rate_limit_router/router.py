"""Rate-limit check -> primary call with timeout -> fallback -> sanitized
response. ModelRouter.route() is the single entry point.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass

from providers import CompletionResult, ModelProvider, UpstreamError, UpstreamRateLimited
from rate_limiter import RateLimitResult, SlidingWindowRateLimiter

logger = logging.getLogger("router")

PRIMARY_TIMEOUT_SECONDS = 3.0

ERR_RATE_LIMITED = "RATE_LIMIT_EXCEEDED"
ERR_ALL_PROVIDERS_FAILED = "ALL_PROVIDERS_UNAVAILABLE"
ERR_INTERNAL = "INTERNAL_ERROR"


@dataclass
class GatewayError:
    code: str
    message: str
    retry_after_seconds: float | None = None

    def to_dict(self) -> dict:
        d = {"error": {"code": self.code, "message": self.message}}
        if self.retry_after_seconds is not None:
            d["error"]["retry_after_seconds"] = self.retry_after_seconds
        return d


@dataclass
class GatewaySuccess:
    provider_used: str
    text: str
    fallback_used: bool
    latency_ms: float

    def to_dict(self) -> dict:
        return {
            "provider_used": self.provider_used,
            "text": self.text,
            "fallback_used": self.fallback_used,
            "latency_ms": round(self.latency_ms, 1),
        }


class ModelRouter:
    def __init__(
        self,
        rate_limiter: SlidingWindowRateLimiter,
        primary: ModelProvider,
        secondary: ModelProvider,
        primary_timeout_seconds: float = PRIMARY_TIMEOUT_SECONDS,
    ) -> None:
        self._rate_limiter = rate_limiter
        self._primary = primary
        self._secondary = secondary
        self._timeout = primary_timeout_seconds

    async def route(self, tenant_key: str, prompt: str, estimated_tokens: int) -> tuple[GatewaySuccess | GatewayError, int]:
        rl_result: RateLimitResult = await self._rate_limiter.try_consume(tenant_key, estimated_tokens)
        if not rl_result.admitted:
            logger.warning(
                "rate limit exceeded tenant=%s used=%d limit=%d",
                tenant_key, rl_result.tokens_used_in_window, rl_result.limit,
            )
            return (
                GatewayError(
                    code=ERR_RATE_LIMITED,
                    message=(
                        f"Token rate limit exceeded ({rl_result.tokens_used_in_window}/{rl_result.limit} "
                        f"tokens used in the trailing 60s window)."
                    ),
                    retry_after_seconds=rl_result.retry_after_seconds,
                ),
                429,
            )

        start = time.monotonic()
        result, fallback_used = await self._call_with_fallback(prompt)
        elapsed_ms = (time.monotonic() - start) * 1000

        if result is None:
            return (
                GatewayError(
                    code=ERR_ALL_PROVIDERS_FAILED,
                    message="All upstream model providers are currently unavailable. Please retry shortly.",
                ),
                502,
            )

        return (
            GatewaySuccess(
                provider_used=result.provider_name,
                text=result.text,
                fallback_used=fallback_used,
                latency_ms=elapsed_ms,
            ),
            200,
        )

    async def _call_with_fallback(self, prompt: str) -> tuple[CompletionResult | None, bool]:
        try:
            result = await asyncio.wait_for(self._primary.complete(prompt), timeout=self._timeout)
            return result, False
        except asyncio.TimeoutError:
            logger.warning("primary '%s' timed out after %.1fs, failing over to '%s'", self._primary.name, self._timeout, self._secondary.name)
        except UpstreamRateLimited:
            logger.warning("primary '%s' returned 429, failing over to '%s'", self._primary.name, self._secondary.name)
        except UpstreamError as e:
            logger.error("primary '%s' failed: %s", self._primary.name, e)

        try:
            result = await asyncio.wait_for(self._secondary.complete(prompt), timeout=self._timeout)
            return result, True
        except asyncio.TimeoutError:
            logger.error("secondary '%s' also timed out", self._secondary.name)
        except UpstreamRateLimited:
            logger.error("secondary '%s' also returned 429", self._secondary.name)
        except UpstreamError as e:
            logger.error("secondary '%s' also failed: %s", self._secondary.name, e)

        return None, True
