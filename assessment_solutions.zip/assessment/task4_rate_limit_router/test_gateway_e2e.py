"""
End-to-end HTTP test for gateway_router.py, in-process via httpx.ASGITransport.

Run: python3 test_gateway_e2e.py
"""
import asyncio
import os
import sys
import tempfile

import httpx

PASS = 0
FAIL = 0


def check(label: str, cond: bool, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS: {label}")
    else:
        FAIL += 1
        print(f"  FAIL: {label} {extra}")


async def main():
    with tempfile.TemporaryDirectory() as d:
        os.environ["RATE_LIMIT_DB"] = os.path.join(d, "e2e.db")

        # Import after setting the env var so gateway_router.py picks it up
        # when it constructs its module-level SlidingWindowRateLimiter.
        import gateway_router

        transport = httpx.ASGITransport(app=gateway_router.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://gw.local") as client:

            resp = await client.post(
                "/v1/completions",
                json={"tenant_key": "acme-corp", "prompt": "hi there", "estimated_tokens": 500},
            )
            body = resp.json()
            check("200 OK on normal request", resp.status_code == 200, resp.status_code)
            check("response has provider_used", "provider_used" in body, body)

            resp2 = await client.post(
                "/v1/completions",
                json={"tenant_key": "acme-corp", "prompt": "hi again", "estimated_tokens": 60_000},
            )
            body2 = resp2.json()
            check("429 when a single request exceeds the 50k/min limit", resp2.status_code == 429, resp2.status_code)
            check("error code RATE_LIMIT_EXCEEDED", body2["error"]["code"] == "RATE_LIMIT_EXCEEDED", body2)

            resp3 = await client.post("/v1/completions", json={"tenant_key": "acme-corp"})
            check("400 on missing estimated_tokens", resp3.status_code == 400, resp3.status_code)

    print(f"\n{PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    asyncio.run(main())
