"""
Unit tests for ModelRouter: fallback on 429, fallback on timeout, both-fail
error sanitization, and rate-limit short-circuiting.

Run: python3 test_router.py
"""
import asyncio
import os
import sys
import tempfile

from providers import MockProvider
from rate_limiter import SlidingWindowRateLimiter
from router import ERR_ALL_PROVIDERS_FAILED, ERR_RATE_LIMITED, GatewayError, GatewaySuccess, ModelRouter

PASS = 0
FAIL = 0


def check(label: str, cond: bool, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS: {label}")
    else:
        FAIL += 1
        print(f"  FAIL: {label} {extra}")


def make_router(primary: MockProvider, secondary: MockProvider, db_dir: str, timeout=0.2) -> ModelRouter:
    rl = SlidingWindowRateLimiter(os.path.join(db_dir, "router_test.db"), limit_tokens_per_window=100_000)
    return ModelRouter(rl, primary, secondary, primary_timeout_seconds=timeout)


async def test_primary_success_no_fallback():
    with tempfile.TemporaryDirectory() as d:
        primary = MockProvider("primary", mode="ok", latency=0.01)
        secondary = MockProvider("secondary", mode="ok", latency=0.01)
        router = make_router(primary, secondary, d)

        payload, status = await router.route("tenant-1", "hello", 100)
        check("status 200 on primary success", status == 200, status)
        check("isinstance GatewaySuccess", isinstance(payload, GatewaySuccess), payload)
        check("provider_used is primary", payload.provider_used == "primary", payload.to_dict())
        check("fallback_used is False", payload.fallback_used is False, payload.to_dict())


async def test_primary_429_triggers_fallback():
    with tempfile.TemporaryDirectory() as d:
        primary = MockProvider("primary", mode="429", latency=0.01)
        secondary = MockProvider("secondary", mode="ok", latency=0.01)
        router = make_router(primary, secondary, d)

        payload, status = await router.route("tenant-2", "hello", 100)
        check("status 200 after failover", status == 200, status)
        check("provider_used is secondary", payload.provider_used == "secondary", payload.to_dict())
        check("fallback_used is True", payload.fallback_used is True, payload.to_dict())


async def test_primary_timeout_triggers_fallback():
    with tempfile.TemporaryDirectory() as d:
        # Primary takes 5s to respond; router timeout is 0.2s -- must fail
        # over quickly, not wait the full 5s.
        primary = MockProvider("primary", mode="timeout", latency=5.0)
        secondary = MockProvider("secondary", mode="ok", latency=0.01)
        router = make_router(primary, secondary, d, timeout=0.2)

        start = asyncio.get_event_loop().time()
        payload, status = await router.route("tenant-3", "hello", 100)
        elapsed = asyncio.get_event_loop().time() - start

        check("status 200 after timeout failover", status == 200, status)
        check("provider_used is secondary", payload.provider_used == "secondary", payload.to_dict())
        check("fallback_used is True", payload.fallback_used is True, payload.to_dict())
        check(f"failover happened fast (~{elapsed:.2f}s), did not wait for the 5s primary", elapsed < 1.0, elapsed)


async def test_both_providers_fail_returns_sanitized_error():
    with tempfile.TemporaryDirectory() as d:
        primary = MockProvider("primary", mode="error", latency=0.01)
        secondary = MockProvider("secondary", mode="error", latency=0.01)
        router = make_router(primary, secondary, d)

        payload, status = await router.route("tenant-4", "hello", 100)
        check("status 502 when both fail", status == 502, status)
        check("isinstance GatewayError", isinstance(payload, GatewayError), payload)
        check("error code is ALL_PROVIDERS_UNAVAILABLE", payload.code == ERR_ALL_PROVIDERS_FAILED, payload)

        d_dict = payload.to_dict()
        rendered = str(d_dict)
        check("no file paths leaked", "/internal/secret_module.py" not in rendered, rendered)
        check("no secrets leaked", "hunter2" not in rendered, rendered)
        check("no 'Traceback' leaked", "Traceback" not in rendered, rendered)


async def test_rate_limit_short_circuits_before_calling_providers():
    with tempfile.TemporaryDirectory() as d:
        calls = {"primary": 0, "secondary": 0}

        class CountingProvider(MockProvider):
            async def complete(self, prompt):
                calls[self.name] += 1
                return await super().complete(prompt)

        primary = CountingProvider("primary", mode="ok", latency=0.01)
        secondary = CountingProvider("secondary", mode="ok", latency=0.01)
        rl = SlidingWindowRateLimiter(os.path.join(d, "rl.db"), limit_tokens_per_window=1000)
        router = ModelRouter(rl, primary, secondary, primary_timeout_seconds=0.2)

        ok_payload, ok_status = await router.route("tenant-5", "hi", 900)
        check("first request (under limit) admitted", ok_status == 200, ok_status)

        blocked_payload, blocked_status = await router.route("tenant-5", "hi", 200)
        check("second request blocked by rate limiter", blocked_status == 429, blocked_status)
        check("error code is RATE_LIMIT_EXCEEDED", blocked_payload.code == ERR_RATE_LIMITED, blocked_payload)
        check(
            "providers NOT called when rate-limited (short-circuited)",
            calls == {"primary": 1, "secondary": 0},
            calls,
        )


async def main():
    await test_primary_success_no_fallback()
    await test_primary_429_triggers_fallback()
    await test_primary_timeout_triggers_fallback()
    await test_both_providers_fail_returns_sanitized_error()
    await test_rate_limit_short_circuits_before_calling_providers()

    print(f"\n{PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    asyncio.run(main())
