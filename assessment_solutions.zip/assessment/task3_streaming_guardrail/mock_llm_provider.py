"""Mock upstream LLM provider: streams a canned response in chunks that are
deliberately split in awkward places (mid-email, mid-card-number) so the
redactor's windowing logic actually gets exercised. Swap stream_completion()
for a real streaming HTTP client call in production.
"""
from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator

_SCRIPTED_CHUNKS: list[str] = [
    "Sure, I can help. Your account contact is ",
    "jane.doe",
    "@examp",
    "le.com",
    " and we have your SSN on file as 123",
    "-45-6789",
    " for verification. The card ending in your statement is 4111 1111 ",
    "1111 1111",
    " -- please confirm the last four digits. ",
    "Let me know if you have other ",
    "questions!",
]


async def stream_completion(prompt: str | None = None) -> AsyncIterator[str]:
    for chunk in _SCRIPTED_CHUNKS:
        await asyncio.sleep(0.01)
        yield chunk
