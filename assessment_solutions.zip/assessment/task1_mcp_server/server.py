"""MCP server exposing customer record lookup and refund tools.

stdio transport. All logging goes to stderr — stdout is reserved for
JSON-RPC and must never get polluted with a stray print().
"""

from __future__ import annotations

import json
import logging
import re
import sys
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.shared.exceptions import McpError
from mcp import types
from mcp.types import (
    ErrorData,
    INVALID_PARAMS,
    METHOD_NOT_FOUND,
    INTERNAL_ERROR,
    CallToolResult,
    ServerResult,
    TextContent,
    Tool,
)
from pydantic import BaseModel, Field, ValidationError, field_validator

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [mcp-server] %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("customer-ops-server")

CUSTOMER_ID_PATTERN = re.compile(r"^CUST-\d{5}$")

# in-memory mock store
_CUSTOMERS: dict[str, dict[str, Any]] = {
    "CUST-00001": {
        "customer_id": "CUST-00001",
        "name": "Asha Rao",
        "email": "asha.rao@example.com",
        "balance": 420.50,
        "status": "active",
    },
    "CUST-00002": {
        "customer_id": "CUST-00002",
        "name": "Devon Park",
        "email": "devon.park@example.com",
        "balance": 0.0,
        "status": "suspended",
    },
}


class GetCustomerRecordInput(BaseModel):
    customer_id: str = Field(..., description="Customer ID, e.g. CUST-00042")

    @field_validator("customer_id")
    @classmethod
    def validate_customer_id(cls, v: str) -> str:
        if not CUSTOMER_ID_PATTERN.match(v):
            raise ValueError(f"customer_id must match 'CUST-XXXXX', got: {v!r}")
        return v


class TriggerRefundInput(BaseModel):
    customer_id: str = Field(..., description="Customer ID, e.g. CUST-00042")
    amount: float = Field(..., description="Refund amount, must be positive")
    reason: str = Field(..., description="Reason for refund, min 10 chars")

    @field_validator("customer_id")
    @classmethod
    def validate_customer_id(cls, v: str) -> str:
        if not CUSTOMER_ID_PATTERN.match(v):
            raise ValueError(f"customer_id must match 'CUST-XXXXX', got: {v!r}")
        return v

    @field_validator("amount")
    @classmethod
    def validate_amount(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"amount must be positive, got: {v}")
        return v

    @field_validator("reason")
    @classmethod
    def validate_reason(cls, v: str) -> str:
        if len(v.strip()) < 10:
            raise ValueError(f"reason must be at least 10 characters, got {len(v.strip())}")
        return v


server: Server = Server("customer-ops-server")


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="get_customer_record",
            description="Fetch a customer record by customer_id (format: CUST-XXXXX).",
            inputSchema=GetCustomerRecordInput.model_json_schema(),
        ),
        Tool(
            name="trigger_refund",
            description=(
                "Trigger a refund for a customer. Requires customer_id, a positive "
                "amount, and a reason of at least 10 characters."
            ),
            inputSchema=TriggerRefundInput.model_json_schema(),
        ),
    ]


def _validation_error_to_mcp(exc: ValidationError) -> McpError:
    details = "; ".join(
        f"{'.'.join(str(p) for p in err['loc'])}: {err['msg']}" for err in exc.errors()
    )
    return McpError(ErrorData(code=INVALID_PARAMS, message=f"Invalid parameters: {details}"))


async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    if name == "get_customer_record":
        try:
            parsed = GetCustomerRecordInput.model_validate(arguments)
        except ValidationError as exc:
            raise _validation_error_to_mcp(exc) from exc

        record = _CUSTOMERS.get(parsed.customer_id)
        if record is None:
            return [TextContent(type="text", text=json.dumps({"error": "not_found", "customer_id": parsed.customer_id}))]
        return [TextContent(type="text", text=json.dumps(record))]

    elif name == "trigger_refund":
        try:
            parsed = TriggerRefundInput.model_validate(arguments)
        except ValidationError as exc:
            raise _validation_error_to_mcp(exc) from exc

        record = _CUSTOMERS.get(parsed.customer_id)
        if record is None:
            return [TextContent(type="text", text=json.dumps({"error": "not_found", "customer_id": parsed.customer_id}))]

        logger.info(
            "refund: customer_id=%s amount=%.2f reason=%r",
            parsed.customer_id, parsed.amount, parsed.reason,
        )
        result = {
            "status": "refund_triggered",
            "customer_id": parsed.customer_id,
            "amount": parsed.amount,
            "reason": parsed.reason,
        }
        return [TextContent(type="text", text=json.dumps(result))]

    else:
        raise McpError(ErrorData(code=METHOD_NOT_FOUND, message=f"Unknown tool: {name}"))


# Registered directly instead of via @server.call_tool(): that decorator
# catches every exception (including McpError) and turns it into
# CallToolResult(isError=True) -- tool-result content, not a JSON-RPC
# protocol error. The spec wants invalid-arguments/unknown-tool to come
# back as real JSON-RPC errors (-32602 / -32601), so we bypass it here.
async def _handle_call_tool_request(req: types.CallToolRequest) -> types.ServerResult:
    name = req.params.name
    arguments = req.params.arguments or {}
    content = await call_tool(name, arguments)
    return ServerResult(CallToolResult(content=list(content), isError=False))


server.request_handlers[types.CallToolRequest] = _handle_call_tool_request


async def _run() -> None:
    logger.info("starting customer-ops-server over stdio")
    try:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())
    except Exception:
        logger.exception("fatal error running server")
        raise McpError(ErrorData(code=INTERNAL_ERROR, message="Internal server error"))


def main() -> None:
    import anyio
    anyio.run(_run)


if __name__ == "__main__":
    main()
